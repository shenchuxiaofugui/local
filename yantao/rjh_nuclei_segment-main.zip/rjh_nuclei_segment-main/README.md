# RJH_Nuclei_Segment

RUI JIN Hospital  Automatic segmentation of brain nuclei